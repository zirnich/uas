//header
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>
 //deklarasi fungsi
void display();
void init();
void reshape(int, int);
void keyboard(unsigned char, int, int);
static float ypoz = 0, zpoz = 0, xpoz = 0,a = -9, b = -5,c = -30 ;

//main program
int main (int argc, char** argv){
//inisialisasi
glutInit(&argc, argv);
glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH ); // GLUT_DEPTH : mengalokasikan
 //sumbu z
glutInitWindowPosition(200, 100); //atur sumbu x dan y
glutInitWindowSize(1024, 600); //atur lebar dan tinggi jendela
glutCreateWindow("Jendela 1");
glutDisplayFunc(display); //memanggil fungsi display
glutReshapeFunc(reshape); //memanggil fungsi reshape
glutKeyboardFunc(keyboard); //memanggil fungsi keyboard
init();
glutMainLoop(); //looping program utama
}
void init(){
glClearColor(0.5, 0.5, 0.5, 0.0);


glEnable(GL_NORMALIZE); //normalisasi objek jika ada cahaya yang tidak sesuai
glShadeModel(GL_SMOOTH); //mengaktifkan kehalusan material objek
glEnable(GL_COLOR_MATERIAL); //mengaktifkan setting warna pada objek
}
        void dinding(float x1,float y1,float z1,float x2,float y2,float z2)
        {
        //depan
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1,y1,z1);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(x2,y1,z1);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(x2,y2,z1);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x1,y2,z1);
         //atas
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1,y2,z1);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(x2,y2,z1);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(x2,y2,z2);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x1,y2,z2);
        //belakang
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1,y2,z2);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(x2,y2,z2);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(x2,y1,z2);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x1,y1,z2);
        //bawah
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1,y1,z2);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x2,y1,z2);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(x2,y1,z1);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(x1,y1,z1);
        //samping kiri
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1,y1,z1);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x1,y2,z1);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(x1,y2,z2);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(x1,y1,z2);
        //samping kanan
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x2,y1,z1);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x2,y2,z1);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(x2,y2,z2);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(x2,y1,z2);
         }

void display(){
 //reset
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity ();
    glEnable(GL_DEPTH_TEST);
    //perpindahan
    glTranslatef(a,b,c);
    //lantai
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.3f, 0.3f, 0.3f);
    dinding(0, 0, 18, 25, 0.5, -20);
    //karpet
    glColor3f(0.0f, 0.0f, 0.0f);
    dinding(0, 0, 15, 10, 0.8, 1);
    //bantal karpet
    glColor3f(1.0f, 1.0f, 1.0f);
    dinding(6, 0, 8, 8, 1.0, 4);
     dinding(6, 0, 15, 8, 1.0, 11);
    glEnd();
    glPopMatrix();
    //dinding kiri
    glPushMatrix();

    glBegin(GL_QUADS);
    glColor3f(0,0,0.5 );
    dinding(0, 0.5, 18, 0.5, 10,-20);
    glEnd();
    glPopMatrix();
    //dinding belakang
    glPushMatrix();
    //bawah
    glBegin(GL_QUADS);
    dinding(-10,0,-20,25,10,-21);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.2f,0.1f,0.1f);
    dinding(9.2,2,-4.2,16.8,3,-19);
    glEnd();
    glPopMatrix();
    //tiang kasur
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.2f,0.1f,0.1f);
    dinding(16.2,0,-19,16.8,1.5,-20);
    dinding(16.2,0,-4,16.8,1.5,-5);
    dinding(9,0,-19,9.8,1.5,-20);
    dinding(9,0,-4,9.8,1.5,-5);
    //alas
    dinding(9,1.5,-4,16.8,2,-20);
    //tempat sandar belakang
    dinding(9.2,2,-19,16.8,5,-20);
    glEnd();
    glPopMatrix();
    //bantal
    glPushMatrix();
    glColor3f(1.0f,1.0f,1.0f);
    glBegin(GL_QUADS);
    glColor3f(1.1f,1.1f,1.1f);
    dinding(9.3,3,-16.5,13,3.5,-18.7);
    dinding(13.3,3,-16.5,16.5,3.5,-18.7);
    glEnd();
    glPopMatrix();
    //selimut
    glPushMatrix();
    glColor3f(0.5f,0.5f,0.5f);
    glBegin(GL_QUADS);
    dinding(8.8,1,-4.2,9,3.2,-13);
    dinding(9,3,-4.2,16.8,3.2,-13);
    dinding(16.8,1,-4.2,17,3.2,-13);
    glEnd();
    glPopMatrix();
      //ac
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(1.1f,1.1f,1.1f);
    dinding(0.55,8.45,8.2,1.2,9.7,4.5);
    glColor3f(0.0f,0.0f,0.0f);
    dinding(1.2,8.5,8.2,1.25,8.45,4.5);
    dinding(1.2,8.6,8.1,1.25,8.62,4.6);
    dinding(1.2,9.58,8.1,1.25,9.6,7);
    dinding(1.2,9.52,8.2,1.25,9.54,6.5);
    dinding(0.55,8.39,8.1,1.15,8.4,4.6);
    glEnd();
    glPopMatrix();
       //tv
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.3f,0.3f,0.3f);
    dinding(0.6,3.6,11.5,0.61,5.8,4.9);
    glColor3f(0.0f,0.0f,0.0f);
    dinding(0.5,3.4,11.7,0.6,6,4.7);
    glEnd();
    glPopMatrix();

    //meja 1
    glPushMatrix();

    glTranslated(9, -3 ,-16.7);
    glBegin(GL_QUADS);
    glColor3f(0.2f,0.1f,0.1f);
    dinding(-7,3,0,-6.5,5,0.3);
    dinding(-2.5,3,0,-2,5,0.3);
    dinding(-7,3,-3,-6.5,5,-3.3);
    dinding(-2.5,3,-3,-2,5,-3.3);
    //atas
    dinding(-7,5,0.3,-2,5.3,-3.3);
    glEnd();
    glPopMatrix();


    //laptop
    glPushMatrix();

    glTranslated(11, -0.65 ,-18.7);
    glBegin(GL_QUADS);
    glColor3f(0.0f,0.0f,0.0f);
    dinding(-8,3,0,-5,4.5,0.3);
    dinding(-8,3,0,-5,3.3,2.5);

    glEnd();
    glPopMatrix();
    glPushMatrix();

    glTranslated(11.4, -0.1 ,-18.4);
    glBegin(GL_QUADS);
    glColor3f(1.0f,1.0f,1.0f);
    dinding(-8,2.5,0,-5.8,3.7,0.1);
    glEnd();
    glPopMatrix();

    //lemari kiri
    glPushMatrix();

    glTranslated(-1,7,-21);

    glTranslated(1,-7,21);
    glBegin(GL_QUADS);
        glColor3f(0.2f,0.1f,0.1f);

    dinding(0,7,-12,3,9,-20);
    glEnd();
    glPopMatrix();

    //lemari kanan
    glPushMatrix();

    glTranslated(7,7,-21);

    glTranslated(-7,-7,21);
    glBegin(GL_QUADS);
        glColor3f(0.2f,0.1f,0.1f);

    dinding(7,7,-12,3,9,-20);
    glEnd();
    glPopMatrix();
    //meja
    //atas
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.2f,0.1f,0.1f);
    dinding(21,3.5,16,24.8,3.8,9.5);
    //kaki kanan belakang
    dinding(24.3,0.5,15.9,24.6,3.6,15.6);
    //kaki kiri belakang
    dinding(24.3,0.5,9.9,24.6,3.6,9.6);
    //kaki kiri depan
    dinding(21.1,0.5,9.9,21.4,3.6,9.6);
    //kaki kanan depan
    dinding(21.1,0.5,15.9,21.4,3.6,15.6);
    //belakang bawah
    dinding(24.4,1,15.6,24.6,1.6,9.9);
    //kanan bawah
    dinding(21.4,1,15.9,24.3,1.6,15.7);
    //kiri bawah
    dinding(21.4,1,9.8,24.3,1.6,9.9);
    glEnd();
    glPopMatrix();
    //kursi
    //alas
    glPushMatrix();

    glBegin(GL_QUADS);
    glColor3f (0.0,0.0,0.0);
    dinding(18,2.2,15.5,20.8,2.5,12.8);
    //kiri depan
    dinding(20.5,0.5,15.5,20.8,2.5,15.2);
    //kanan depan
    dinding(20.5,0.5,13.1,20.8,2.5,12.8);
    //kanan belakang
    dinding(18,0.5,13.1,18.3,5.2,12.8);
    //kiri belakang
    dinding(18,0.5,15.5,18.3,5.2,15.2);
    //senderan
    dinding(18,3.8,15.5,18.2,4.9,12.8);
    glEnd();
    glPopMatrix();
    glPushMatrix();

    glBegin(GL_QUADS);
    glColor3f(0.0f,0.0f,0.0f);

    //PC
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.0f,0.0f,0.0f);
    //cpu
    dinding(21.5,3.8,11.8,23.5,6,10.8);
    //Monitor lcd
    dinding(23.3,4.1,15.5,23.5,6.4,12.2);
    dinding(23.5,4.3,15.3,23.6,6.2,12.4);
    dinding(23.6,3.8,14,23.8,6,13.5);
    dinding(23.4,3.8,14.3,23.9,4,13.2);
    //keyboard
    dinding(21.8,3.8,12.3,23,4,15.2);
    glEnd();
    glPopMatrix();
    //layar lcd
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.3f,0.3f,0.3f);
    dinding(23.29,4.3,15.3,23.29,6.2,12.4);
    glEnd();
    glPopMatrix();
    //cpu
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.3f,0.3f,0.3f);
    dinding(21.49,3.8,11.8,21.5,6,10.8);
    glEnd();
    glPopMatrix();

    glPopMatrix();



    //lemari pakaian
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f (0.2f,0.1f,0.1f);
    dinding(16,0.6,-15,23.8,8.5,-20);
    //kanan
    dinding(23.8,0.5,-15,24,8.7,-20);
    //kiri
    dinding(15.8,0.5,-15,16,8.7,-20);
    //gagang pintu kiri
    glColor3f (0.2f,0.1f,0.1f);
    dinding(19.3,4.5,-15,19.5,5.7,-13.3);
    //gagang pintu kanan
    dinding(20.3,4.5,-15,20.5,5.7,-13.3);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glBegin(GL_QUADS);
    glColor3f(0.0,0.0,0.0);
    //pintu kiri
    dinding(16.2,0.9,-17,19.7,8.3,-13.8);
    //pintu kanan
    dinding(20.1,0.9,-17,23.6,8.3,-13.8);
    glEnd();
    glPopMatrix();



    glFlush();
    glutSwapBuffers();
}
//fungsi untuk setting viewport
void reshape(int w, int h){
glViewport(0,0, (GLsizei)w, (GLsizei)h); //membuat viewport sesuai ukuran jendela
glMatrixMode(GL_PROJECTION); //merubah matrix mode menjadi gl_projection
glLoadIdentity(); //reset transformasi misalnya rotasi pada display
gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0); //setting proyeksi perspektif
glTranslatef(0.0f, 0.0f, -10.0f); //tentukan posisi awal
                                    //gluLookAt(0., 0., 0., 1., -1., 1., 0., 1., 0.); //camera
glMatrixMode(GL_MODELVIEW); //merubah matrix mode menjadi gl_modelview
}

void keyboard(unsigned char key, int x, int y)
{
/* this is the keyboard event handler
 the x and y parameters are the mouse
 coordintes when the key was struck */
switch (key)
{
case 'a':
case 'A':
glTranslatef(1.0, 0.0, 0.0);
break;
case 'd':
case 'D':
glTranslatef(-1.0, 0.0, 0.0);
break;
case 'w':
case 'W':
glTranslatef(0.0, 0.0, 1.0);
break;
case 's':
case 'S':
glTranslatef(0.0, 0.0, -1.0);
break;
 case 'l':
case 'L':
 glRotatef(.5, 0.0, 1.0, 0.0); /* rotate left */
break;
case 'r':
case 'R':
glRotatef(-.5, 0.0, 1.0, 0.0); /* rotate right */
break;
 case 'u':
case 'U':
 glRotatef(1.0, 1.0, 0.0, 0.0); /* rotate up */
break;
case 'j':
case 'J':
glRotatef(-1.0, 1.0, 0.0, 0.0); /* rotate down */
break;
}
display(); //memanggil fungsi display atau bisa pakai glutPostRedisplay();
}
